package com.mongodb.mongodbtest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MongodbtestApplicationTests {

	@Test
	void contextLoads() {
	}

}
