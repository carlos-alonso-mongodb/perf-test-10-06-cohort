from helper import execute_aggregation
from datetime import datetime


def run_aggregation():
    pipeline = [
        {
            '$search': {
                'index': 'default',
                'returnStoredSource': False,
                'compound': {
                    'filter': [
                        # 1) hx = 441413179318273660 and time between 2000-04-13 and 2025-04-13
                        {
                            'embeddedDocument': {
                                'path': 'sn',
                                'operator': {
                                    'compound': {
                                        'filter': [
                                            {'equals': {'path': 'sn.hx',      'value': 441413179318273660}},
                                            {'range':  {'path': 'sn.d.time.v', 'gte': datetime(2000, 4, 13, 7, 54, 16, 345000), 'lte': datetime(2025, 4, 13, 7, 54, 16, 345000)}}
                                        ]
                                    }
                                }
                            }
                        },
                        # 2) hx = -99357964256156270 and code = 'E0000X1'
                        {
                            'embeddedDocument': {
                                'path': 'sn',
                                'operator': {
                                    'compound': {
                                        'filter': [
                                            {'equals': {'path': 'sn.hx',        'value': -99357964256156270}},
                                            {'equals': {'path': 'sn.d.v.df.cs', 'value': 'E0000X50'}}
                                        ]
                                    }
                                }
                            }
                        }
                    ]
                },
                'sort': {
                    'sort-time': -1
               },
              'concurrent': True
            }
        },
        {'$limit': 100},
        {
            '$lookup': {
                'from':       'compositions',
                'localField': '_id',
                'foreignField': '_id',
                'as':         'comp'
            }
        },
        {'$unwind': '$comp'},
        # project required fields
        {
            '$project': {
                '_id': 0,
                'time': {
                    '$arrayElemAt': [
                        {'$map': {
                            'input': {'$filter': {
                                'input': '$comp.cn',
                                'as': 'node',
                                'cond': {'$in': [ -4525396453480898112, '$$node.pch' ]}
                            }},
                            'as': 'node',
                            'in': '$$node.d.time.v'
                        }},
                        0
                    ]
                },
                'Centro': {
                    '$arrayElemAt': [
                        {'$map': {
                            'input': {'$filter': {
                                'input': '$comp.cn',
                                'as': 'node',
                                'cond': {'$in': [ -7030779161720247090, '$$node.pch' ]}
                            }},
                            'as': 'node',
                            'in': '$$node.d.v.df.cs'
                        }},
                        0
                    ]
                },
                'Profesional': {
                    '$arrayElemAt': [
                        {'$map': {
                            'input': {'$filter': {
                                'input': '$comp.cn',
                                'as': 'node',
                                'cond': {'$in': [ 4601451072787876934, '$$node.pch' ]}
                            }},
                            'as': 'node',
                            'in': '$$node.d.op'
                        }},
                        0
                    ]
                },
                'MarcaComercial': {
                    '$arrayElemAt': [
                        {'$map': {
                            'input': {'$filter': {
                                'input': '$comp.cn',
                                'as': 'node',
                                'cond': {'$in': [ -4498846432378297709, '$$node.pch' ]}
                            }},
                            'as': 'node',
                            'in': '$$node.d.v.mappings.target.cs'
                        }},
                        0
                    ]
                },
                'CodiNacional': {
                    '$arrayElemAt': [
                        {'$map': {
                            'input': {'$filter': {
                                'input': '$comp.cn',
                                'as': 'node',
                                'cond': {'$in': [ 4384801327358952620, '$$node.pch' ]}
                            }},
                            'as': 'node',
                            'in': '$$node.d.v'
                        }},
                        0
                    ]
                },
                'FechaAdmin': {
                    '$arrayElemAt': [
                        {'$map': {
                            'input': {'$filter': {
                                'input': '$comp.cn',
                                'as': 'node',
                                'cond': {'$in': [ 4601451072787876934, '$$node.pch' ]}
                            }},
                            'as': 'node',
                            'in': '$$node.d.time.v'
                        }},
                        0
                    ]
                },
                'Estado': {
                    '$arrayElemAt': [
                        {'$map': {
                            'input': {'$filter': {
                                'input': '$comp.cn',
                                'as': 'node',
                                'cond': {'$in': [ 4601451072787876934, '$$node.pch' ]}
                            }},
                            'as': 'node',
                            'in': '$$node.d.ism_transition.current_state.v'
                        }},
                        0
                    ]
                },
                'NombreGenerico': {
                    '$arrayElemAt': [
                        {'$map': {
                            'input': {'$filter': {
                                'input': '$comp.cn',
                                'as': 'node',
                                'cond': {'$in': [ 1981395971480157104, '$$node.pch' ]}
                            }},
                            'as': 'node',
                            'in': '$$node.d'
                        }},
                        0
                    ]
                },
                'Lote': {
                    '$arrayElemAt': [
                        {'$map': {
                            'input': {'$filter': {
                                'input': '$comp.cn',
                                'as': 'node',
                                'cond': {'$in': [ 4384801327358952620, '$$node.pch' ]}
                            }},
                            'as': 'node',
                            'in': '$$node.d'
                        }},
                        0
                    ]
                },
                'Caducidad': {
                    '$arrayElemAt': [
                        {'$map': {
                            'input': {'$filter': {
                                'input': '$comp.cn',
                                'as': 'node',
                                'cond': {'$in': [ -8118383464584531045, '$$node.pch' ]}
                            }},
                            'as': 'node',
                            'in': '$$node.d'
                        }},
                        0
                    ]
                },
                'ViaAdmin': {
                    '$arrayElemAt': [
                        {'$map': {
                            'input': {'$filter': {
                                'input': '$comp.cn',
                                'as': 'node',
                                'cond': {'$in': [ 2188366071802999590, '$$node.pch' ]}
                            }},
                            'as': 'node',
                            'in': '$$node.d'
                        }},
                        0
                    ]
                },
                'LocalizAdmin': {
                    '$arrayElemAt': [
                        {'$map': {
                            'input': {'$filter': {
                                'input': '$comp.cn',
                                'as': 'node',
                                'cond': {'$in': [ -6062739608922506730, '$$node.pch' ]}
                            }},
                            'as': 'node',
                            'in': '$$node.d'
                        }},
                        0
                    ]
                }
            }
        }
    ]

    # execute against 'mydb.search'
    return execute_aggregation("CatSalutCDR.search", pipeline)