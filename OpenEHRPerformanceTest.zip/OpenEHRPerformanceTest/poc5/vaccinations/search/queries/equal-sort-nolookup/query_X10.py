from helper import execute_aggregation
from datetime import datetime


def run_aggregation():
    pipeline = [
        {
            '$search': {
                'index': 'default',
                'returnStoredSource': True,
                'compound': {
                    'filter': [
                        # 1) hx = 441413179318273660 and time between 2000-04-13 and 2025-04-13
                        {
                            'embeddedDocument': {
                                'path': 'sn',
                                'operator': {
                                    'compound': {
                                        'filter': [
                                            {'equals': {'path': 'sn.hx',      'value': 441413179318273660}},
                                            {'range':  {'path': 'sn.d.time.v', 'gte': datetime(2000, 4, 13, 7, 54, 16, 345000), 'lte': datetime(2025, 4, 13, 7, 54, 16, 345000)}}
                                        ]
                                    }
                                }
                            }
                        },
                        # 2) hx = -99357964256156270 and code = 'E0000X1'
                        {
                            'embeddedDocument': {
                                'path': 'sn',
                                'operator': {
                                    'compound': {
                                        'filter': [
                                            {'equals': {'path': 'sn.hx',        'value': -99357964256156270}},
                                            {'equals': {'path': 'sn.d.v.df.cs', 'value': 'E0000X10'}}
                                        ]
                                    }
                                }
                            }
                        }
                    ]
                },
                'sort': {
                    'sort-time': -1
               },
              'concurrent': True
            }
        },
        {'$limit': 100}
    ]

    # execute against 'mydb.search'
    return execute_aggregation("CatSalutCDR.search", pipeline)