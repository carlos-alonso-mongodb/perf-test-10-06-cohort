# Laboratory/search/query_X1.py

from helper import execute_aggregation
from datetime import datetime


def run_aggregation():
    pipeline = [
        {
            '$search': {
                'index': 'default',
                'returnStoredSource': True,
                'compound': {
                    'filter': [
                        # 1) match hx + status "Negatiu"
                        {
                            'embeddedDocument': {
                                'path': 'sn',
                                'operator': {
                                    'compound': {
                                        'filter': [
                                            {'equals': {'path': 'sn.hx',      'value': 4432367513544359000}},
                                            {'equals': {'path': 'sn.d.v.v',   'value': 'NegatiuX50'}}
                                        ]
                                    }
                                }
                            }
                        },
                        # 2) date >= 2021-01-19
                        {
                            'embeddedDocument': {
                                'path': 'sn',
                                'operator': {
                                    'compound': {
                                        'filter': [
                                            {'range': {
                                                'path': 'sn.d.cx.st.v',
                                                'gte': datetime(2021, 1, 19, 0, 0, 0)
                                            }}
                                        ]
                                    }
                                }
                            }
                        },
                        # 3) hx + date <= 2025-01-01T08:04:47
                        {
                            'embeddedDocument': {
                                'path': 'sn',
                                'operator': {
                                    'compound': {
                                        'filter': [
                                            {'equals': {'path': 'sn.hx',    'value': 8176112164324083000}},
                                            {'range': {
                                                'path': 'sn.d.v.v',
                                                'lte': datetime(2025, 1, 1, 8, 4, 47)
                                            }}
                                        ]
                                    }
                                }
                            }
                        },
                        # 4) hx + specific code
                        {
                            'embeddedDocument': {
                                'path': 'sn',
                                'operator': {
                                    'compound': {
                                        'filter': [
                                            {'equals': {'path': 'sn.hx',         'value': 7091782012172163000}},
                                            {'equals': {'path': 'sn.d.v.df.cs', 'value': 'H43001903'}}
                                        ]
                                    }
                                }
                            }
                        },
                        # 5) hx + in-list codes
                        {
                            'embeddedDocument': {
                                'path': 'sn',
                                'operator': {
                                    'compound': {
                                        'filter': [
                                            {'equals': {'path': 'sn.hx', 'value': 2664869662100525000}},
                                            {'in': {
                                                'path': 'sn.d.v.df.cs',
                                                'value': [
                                                    '789-8','718-7','62461000122102','16676-9',
                                                    '10851-4','LL1937-3','88186-2','77955-3',
                                                    '41216-3','7894-9','16925-0','38392-7',
                                                    '31870-9','74408-6','17327-8','98080-5',
                                                    '82301-3','31946-7','31947-5','21834-2',
                                                    '21835-9','31966-5','21503-8','60270-6',
                                                    '33689-1','82731-1'
                                                ]
                                            }}
                                        ]
                                    }
                                }
                            }
                        }
                    ]
                },
                'sort': {
                    'sort-time': -1
               },
              'concurrent': True
            }
        },
        {'$limit': 100},
        {
            '$lookup': {
                'from':       'compositions',
                'localField': '_id',
                'foreignField':'_id',
                'as':         'comp'
            }
        },
        {'$unwind': '$comp'},
        # project fields
        {
            '$project': {
                '_id': 0,
                'EHR_ID':                '$comp.ehr_id',
                'COMPOSITION_START_TIME':'$comp.cn.d.cx.st.v',
                'COMPOSER':              '$comp.cn.0.d.cpr.n',
                'REQUESTING_EP': {
                    '$arrayElemAt': [
                        {
                            '$map': {
                                'input': {
                                    '$filter': {
                                        'input': '$comp.cn',
                                        'as': 'node',
                                        'cond': {
                                            '$in': [5022794523899423442, '$$node.pch']
                                        }
                                    }
                                },
                                'as': 'node',
                                'in': '$$node.d'
                            }
                        },
                        0
                    ]
                },
                'AUTHORIZATION_DATE': {
                    '$arrayElemAt': [
                        {
                            '$map': {
                                'input': {
                                    '$filter': {
                                        'input': '$comp.cn',
                                        'as': 'node',
                                        'cond': {
                                            '$in': [8858090374367138130, '$$node.pch']
                                        }
                                    }
                                },
                                'as': 'node',
                                'in': '$$node.d'
                            }
                        },
                        0
                    ]
                },
                'TEST_NAME': {
                    '$arrayElemAt': [
                        {
                            '$map': {
                                'input': {
                                    '$filter': {
                                        'input': '$comp.cn',
                                        'as': 'node',
                                        'cond': {
                                            '$in': [9145840891920050841, '$$node.pch']
                                        }
                                    }
                                },
                                'as': 'node',
                                'in': '$$node.d.v.df.cs'
                            }
                        },
                        0
                    ]
                },
                'LAB_PERFORMER': {
                    '$arrayElemAt': [
                        {
                            '$map': {
                                'input': {
                                    '$filter': {
                                        'input': '$comp.cn',
                                        'as': 'node',
                                        'cond': {
                                            '$in': [5677167347966923126, '$$node.pch']
                                        }
                                    }
                                },
                                'as': 'node',
                                'in': '$$node.d.op.pf.ids.id'
                            }
                        },
                        0
                    ]
                }
            }
        }
    ]

    # namespace.collection, e.g., "mydb.search"
    return execute_aggregation("CatSalutCDR.search", pipeline)