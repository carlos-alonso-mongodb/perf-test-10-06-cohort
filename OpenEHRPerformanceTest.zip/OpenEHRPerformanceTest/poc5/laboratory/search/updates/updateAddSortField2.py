#!/usr/bin/env python3
"""
rename_sort_field_by_ids.py – read a list of _ids from ids.txt, for each:
  • rename top-level field "sort_time" to "sort-time"

Run:
    python rename_sort_field_by_ids.py --db CatSalutCDR --coll search \
        --ids-file ids_with_sort_time.txt --batch-size 1000
"""

import os
import argparse
from pathlib import Path
from pymongo import MongoClient, UpdateOne
from pymongo.errors import BulkWriteError
from bson import ObjectId

# ---------- parse CLI args ----------
parser = argparse.ArgumentParser()
parser.add_argument("--db",       required=True, help="database name")
parser.add_argument("--coll",     required=True, help="collection name")
parser.add_argument("--ids-file", required=True,
                    help="newline-delimited file of ObjectId hex strings")
parser.add_argument("--batch-size", type=int, default=1000,
                    help="how many updates per bulkWrite (default: 1000)")
args = parser.parse_args()

# ---------- connect to MongoDB ----------
client = MongoClient(
    host=os.environ.get("MONGODB_URI"),
    retryWrites=True,
    tls=True,
    tlsAllowInvalidCertificates=True
)
coll = client[args.db][args.coll]

# ---------- read ids ----------
ids_path = Path(args.ids_file)
with ids_path.open("r") as fh:
    ids = [ObjectId(line.strip()) for line in fh if line.strip()]
print(f"Loaded {len(ids)} _id(s) from {ids_path}")

# ---------- batch‐update function ----------
def process_batch(batch_ids):
    ops = []
    for _id in batch_ids:
        ops.append(
            UpdateOne(
                {"_id": _id, "sort_time": {"$exists": True}},
                {"$rename": {"sort_time": "sort-time"}}
            )
        )
    if not ops:
        return 0
    try:
        result = coll.bulk_write(ops, ordered=False)
        return result.modified_count
    except BulkWriteError as bwe:
        print("Bulk write error:", bwe.details)
        return 0

# ---------- run in batches ----------
total = 0
for i in range(0, len(ids), args.batch_size):
    batch = ids[i : i + args.batch_size]
    updated = process_batch(batch)
    total += updated
    print(f"Batch {i//args.batch_size + 1}: Renamed {updated} docs")

print(f"Done — total fields renamed: {total}")