#!/usr/bin/env python3
"""
update_negatiu.py – find X documents whose sn.hx == HX_VALUE and
sn.d.v.v == "Negatiu", then replace the string with REPLACEMENT.

Run:
    python update_negatiu.py --db lab --coll records \
        --limit 1000 --replacement NegatiuX1000
"""

import os, argparse, pathlib
from pymongo import MongoClient, UpdateOne
from pymongo.errors import BulkWriteError
from datetime import datetime, timezone


# ---------- configuration via CLI ----------
parser = argparse.ArgumentParser()
parser.add_argument("--db", required=True, help="database name")
parser.add_argument("--coll", required=True, help="collection name")
parser.add_argument("--limit", type=int, default=1000,
                    help="how many docs to modify")
parser.add_argument("--replacement", default="NegatiuX1",
                    help='new string that will replace "Negatiu"')
parser.add_argument("--hx", type=int, default=4432367513544358685,
                    help="numeric value of sn.hx to match")
args = parser.parse_args()

# ---------- connect ----------
client = MongoClient(
    host=os.environ["MONGODB_URI"],
    appname="negatiu-updater",
    retryWrites=True,
)
coll = client[args.db][args.coll]


# -- range boundaries -------------------------------------------------
SINCE_2021 = datetime(2021, 1, 19, tzinfo=timezone.utc)
BEFORE_2025 = datetime(2025, 1, 1,  8, 4, 47, tzinfo=timezone.utc)

# -- set of codes for the last embeddedDocument -----------------------
CS_SET = [
    "789-8", "718-7", "62461000122102", "16676-9",
    "10851-4", "LL1937-3", "88186-2", "77955-3",
    "41216-3", "7894-9", "16925-0", "38392-7",
    "17327-8", "98080-5", "82301-3", "31946-7",
    "31947-5", "21834-2", "21835-9", "31966-5",
    "21503-8", "60270-6", "33689-1", "82731-1",
]


# ---------- 1. fetch _id list through $search ----------
pipeline = [
    {
        "$search": {
            "index": "default",          # e.g. "default"
            "compound": {
                "filter": [
                    # --- (1) hx == args.hx  AND  d.v.v == "Negatiu" -----------------
                    {
                        "embeddedDocument": {
                            "path": "sn",
                            "operator": {
                                "compound": {
                                    "filter": [
                                        { "equals": { "path": "sn.hx",     "value": args.hx }},
                                        { "equals": { "path": "sn.d.v.v", "value": "Negatiu" }},
                                    ]
                                }
                            }
                        }
                    },

                    # --- (2) d.cx.st.v  >= 19 Jan 2021 ------------------------------
                    {
                        "embeddedDocument": {
                            "path": "sn",
                            "operator": {
                                "range": {
                                    "path": "sn.d.cx.st.v",
                                    "gte": SINCE_2021
                                }
                            }
                        }
                    },

                    # --- (3) hx == 8176112164324082903  AND  d.v.v  <= 1 Jan 2025 ----
                    {
                        "embeddedDocument": {
                            "path": "sn",
                            "operator": {
                                "compound": {
                                    "filter": [
                                        { "equals": { "path": "sn.hx", "value": 8176112164324082903 }},
                                        { "range":  { "path": "sn.d.v.v", "lte": BEFORE_2025 }}
                                    ]
                                }
                            }
                        }
                    },

                    # --- (4) hx == 7091782012172163454  AND  d.v.df.cs == "H43001903"
                    {
                        "embeddedDocument": {
                            "path": "sn",
                            "operator": {
                                "compound": {
                                    "filter": [
                                        { "equals": { "path": "sn.hx", "value": 7091782012172163454 }},
                                        { "equals": { "path": "sn.d.v.df.cs", "value": "H43001903" }},
                                    ]
                                }
                            }
                        }
                    },

                    # --- (5) hx == 2664869662100525234  AND  d.v.df.cs IN CS_SET -----
                    {
                        "embeddedDocument": {
                            "path": "sn",
                            "operator": {
                                "compound": {
                                    "filter": [
                                        { "equals": { "path": "sn.hx", "value": 2664869662100525234 }},
                                        { "in":     { "path": "sn.d.v.df.cs", "value": CS_SET }},
                                    ]
                                }
                            }
                        }
                    },
                ]
            }
        }
    },
    { "$limit": args.limit },
    { "$project": { "_id": 1 } },
]

ids = [doc["_id"] for doc in coll.aggregate(pipeline, allowDiskUse=True)]
print(f"Fetched {len(ids)} document IDs")

if not ids:
    print("Nothing to update – exiting.")
    exit(0)

# ---------- 2. build bulk updates ----------
bulk_ops = [
    UpdateOne(
        {"_id": _id},
        {"$set": {"sn.$[elem].d.v.v": args.replacement}},
        array_filters=[{
            "elem.hx": args.hx,
            "elem.d.v.v": "Negatiu"
        }],
    )
    for _id in ids
]

# ----- 3. write the list of _ids to disk *before* we run the update -----
out_path = pathlib.Path(f"{args.replacement}.txt")        # e.g. NegatiuX1000.txt
with out_path.open("w", encoding="utf-8") as fh:
    for _id in ids:
        fh.write(f"{_id}\n")

print(f"Wrote {len(ids)} ObjectIds to {out_path.resolve()}")

# ---------- 4. execute bulk write ----------
try:
    result = coll.bulk_write(bulk_ops, ordered=False)
    print(
        f"Matched {result.matched_count} – "
        f"modified {result.modified_count} – "
        f"upserts {result.upserted_count}"
    )
except BulkWriteError as bwe:
    print("Bulk write error:")
    for err in bwe.details["writeErrors"]:
        print(err)