# Laboratory/match/queries/regex/query_X250.py

from helper import execute_aggregation
from datetime import datetime

def run_aggregation():
    pipeline = [
        {
            '$match': {
                'ehr_id': 'X250',
                'cn': {
                    '$all': [
                        {
                            '$elemMatch': {
                                'p': { '$regex': r"^-16\.-7\.3\.-1(?:\.[^.]+)*$"},
                                'd.v.df.cs': '00100'
                            }
                        },
                        {
                            '$elemMatch': {
                                'p': '-1.18.17.16',
                                'd.origin.v': { '$gte': datetime(2000, 11, 9, 0, 0, 0) }
                            }
                        },
                        {
                            '$elemMatch': {
                                'p': '-24.19.-3.-2.-1.18.17.16',
                                'd.v.df.cs': '789-8',
                                'd.v.df.tid.v': '2.16.840.1.113883.6.1'
                            }
                        }
                    ]
                }
            }
        },
        {
            '$addFields': {
                'DataObtencio': {
                    '$arrayElemAt': [
                        {
                            '$map': {
                                'input': {
                                    '$filter': {
                                        'input': '$cn',
                                        'as': 'node',
                                        'cond': {
                                            '$in': [-2364035526164232886, '$$node.pch']
                                        }
                                    }
                                },
                                'as': 'node',
                                'in': '$$node.d.origin.v'
                            }
                        },
                        0
                    ]
                }
            }
        },
        { '$sort': { 'DataObtencio': -1 } },
        { '$limit': 100 },
        {
            '$project': {
                '_id': 0,
                'compositionId': '$comp_id',
                'PUBLISHING_UP': {
                    '$arrayElemAt': [
                        {
                            '$map': {
                                'input': {
                                    '$filter': {
                                        'input': '$cn',
                                        'as': 'node',
                                        'cond': {
                                            '$in': [-5494493541001394526, '$$node.pch']
                                        }
                                    }
                                },
                                'as': 'node',
                                'in': '$$node.d.v.df.cs'
                            }
                        },
                        0
                    ]
                },
                'REQUESTING_UP': {
                    '$arrayElemAt': [
                        {
                            '$map': {
                                'input': {
                                    '$filter': {
                                        'input': '$cn',
                                        'as': 'node',
                                        'cond': {
                                            '$in': [-4043536162575638914, '$$node.pch']
                                        }
                                    }
                                },
                                'as': 'node',
                                'in': '$$node.d.v.df.cs'
                            }
                        },
                        0
                    ]
                },
                'PERFORMING_UP': {
                    '$arrayElemAt': [
                        {
                            '$map': {
                                'input': {
                                    '$filter': {
                                        'input': '$cn',
                                        'as': 'node',
                                        'cond': {
                                            '$in': [-5398665152976622193, '$$node.pch']
                                        }
                                    }
                                },
                                'as': 'node',
                                'in': '$$node.d.v.df.cs'
                            }
                        },
                        0
                    ]
                },
                'AUTHORIZATION_DATE': {
                    '$arrayElemAt': [
                        {
                            '$map': {
                                'input': {
                                    '$filter': {
                                        'input': '$cn',
                                        'as': 'node',
                                        'cond': {
                                            '$in': [-1279651726113222077, '$$node.pch']
                                        }
                                    }
                                },
                                'as': 'node',
                                'in': '$$node.d.v.df'
                            }
                        },
                        0
                    ]
                },
                'DescripcioProva': {
                    '$arrayElemAt': [
                        {
                            '$map': {
                                'input': {
                                    '$filter': {
                                        'input': '$cn',
                                        'as': 'node',
                                        'cond': {
                                            '$in': [-5797776851620394899, '$$node.pch']
                                        }
                                    }
                                },
                                'as': 'node',
                                'in': '$$node.d.v.v'
                            }
                        },
                        0
                    ]
                },
                'CatalegServTerminologic': {
                    '$arrayElemAt': [
                        {
                            '$map': {
                                'input': {
                                    '$filter': {
                                        'input': '$cn',
                                        'as': 'node',
                                        'cond': {
                                            '$in': [-5797776851620394899, '$$node.pch']
                                        }
                                    }
                                },
                                'as': 'node',
                                'in': '$$node.d.v.df.tid.v'
                            }
                        },
                        0
                    ]
                },
                'ValorResultat': {
                    '$arrayElemAt': [
                        {
                            '$map': {
                                'input': {
                                    '$filter': {
                                        'input': '$cn',
                                        'as': 'node',
                                        'cond': {
                                            '$in': [5648826612291266509, '$$node.pch']
                                        }
                                    }
                                },
                                'as': 'node',
                                'in': '$$node.d.v.magnitude'
                            }
                        },
                        0
                    ]
                },
                'RangMinResultat': {
                    '$arrayElemAt': [
                        {
                            '$map': {
                                'input': {
                                    '$filter': {
                                        'input': '$cn',
                                        'as': 'node',
                                        'cond': {
                                            '$in': [5648826612291266509, '$$node.pch']
                                        }
                                    }
                                },
                                'as': 'node',
                                'in': '$$node.d.v.normal_range.lower.magnitude'
                            }
                        },
                        0
                    ]
                },
                'RangMaxResultat': {
                    '$arrayElemAt': [
                        {
                            '$map': {
                                'input': {
                                    '$filter': {
                                        'input': '$cn',
                                        'as': 'node',
                                        'cond': {
                                            '$in': [5648826612291266509, '$$node.pch']
                                        }
                                    }
                                },
                                'as': 'node',
                                'in': '$$node.d.v.normal_range.upper.magnitude'
                            }
                        },
                        0
                    ]
                },
                # Keep DataObtencio in the output
                'DataObtencio': 1
            }
        }
    ]

    return execute_aggregation("CatSalutCDR.compositions", pipeline)