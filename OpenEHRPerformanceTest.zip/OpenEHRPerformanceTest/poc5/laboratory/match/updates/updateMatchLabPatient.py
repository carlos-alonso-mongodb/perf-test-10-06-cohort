#!/usr/bin/env python3
"""
bulk_update_ehr_ids.py – apply multiple range-based suffix mappings to replace entire ehr_id values.

For performance and shard-key safety, this script uses an indexed equality filter (`$in`) on explicit `ehr_id` values.
It then performs each update in isolation with retry/backoff to handle shard-move lock timeouts.

Usage example:
    python bulk_update_ehr_ids.py --db lab --coll records \
      --mapping 77fba862-ab80-4b26-da87-41eaf6e5f2c5~r1:X1 \
      --mapping d53e11ef-bbab-4569-76f7-abf58f4d5e82~r26:X10 \
      --mapping d53e11ef-bbab-4569-76f7-abf58f4d5e82~r1-5:X50 \
      --mapping d53e11ef-bbab-4569-76f7-abf58f4d5e82~r11-35:X50 \
      --mapping d53e11ef-bbab-4569-76f7-abf58f4d5e82~r41-141:X1000 \
      --mapping bb66974a-a1c7-450e-e419-a4c9ae8e3579~r1-150:X5000 \
      --mapping 405b0f79-91bd-4396-ebf2-028eec829963~r1-147:X10000

Each `--mapping` is:
    <ehr_prefix>~r<start>[-<end>]:<new_eid>

This version adds retry logic to each `update_one` to handle transient lock timeouts when moving documents between shards.
"""
import os
import argparse
import re
import time
from pymongo import MongoClient
from pymongo.errors import WriteError, BulkWriteError
from bson.int64 import Int64
from datetime import datetime, timezone

# ---------- CLI configuration ----------
parser = argparse.ArgumentParser(
    description="Bulk replace ehr_id by range-based mappings with per-doc retries"
)
parser.add_argument("--db", required=True, help="database name")
parser.add_argument("--coll", required=True, help="collection name")
parser.add_argument(
    "--mapping", required=True, action="append",
    help=("mapping in form prefix~r{start}[-{end}]:new_eid; "
          "repeat for multiple ranges")
)
parser.add_argument("--limit", type=int, default=None,
                    help="optional per-mapping doc limit")
parser.add_argument("--retries", type=int, default=5,
                    help="max retry attempts per update on lock timeout")
parser.add_argument("--backoff", type=float, default=0.2,
                    help="base backoff seconds (exponential)")
args = parser.parse_args()

# connect to MongoDB
client = MongoClient(
    host=os.environ.get("MONGODB_URI"),
    appname="ehr_id-bulk-updater"
)
coll = client[args.db][args.coll]

# static cn filters
cn_filters = [
    {"$elemMatch": {"pch": Int64(3360793852075631416), "d.v.df.cs": "00100"}},
    {"$elemMatch": {"pch": Int64(5725676661766718380), "d.origin.v": {"$gte": datetime(2000, 11, 9, tzinfo=timezone.utc)}}},
    {"$elemMatch": {"pch": Int64(-5797776851620394899), "d.v.df.cs": "789-8", "d.v.df.tid.v": "2.16.840.1.113883.6.1"}}
]

# pattern to parse mappings
mapping_pattern = re.compile(r"^(?P<prefix>[^~]+)~r(?P<range>\d+(?:-\d+)?):(?P<new_eid>\S+)$")

# helper: safe update with retries
def safe_update(filter_doc, update_doc):
    attempts = 0
    while attempts <= args.retries:
        try:
            res = coll.update_one(filter_doc, update_doc)
            return res
        except WriteError as e:
            code = getattr(e, 'code', None)
            # shard-move lock timeout codes
            if code in (24, 72) and attempts < args.retries:
                sleep_time = args.backoff * (2 ** attempts)
                print(f"    Lock timeout, retry {attempts+1} in {sleep_time:.2f}s...")
                time.sleep(sleep_time)
                attempts += 1
                continue
            else:
                print(f"    Update failed: {e.details if hasattr(e, 'details') else str(e)}")
                return None
    print("    Max retries reached, skipping update.")
    return None

for map_str in args.mapping:
    m = mapping_pattern.match(map_str)
    if not m:
        print(f"Invalid mapping syntax: {map_str}")
        continue

    prefix = m.group('prefix')
    rng = m.group('range')
    new_eid = m.group('new_eid')
    start_str, end_str = rng.split('-') if '-' in rng else (rng, rng)
    start, end = int(start_str), int(end_str)

    target_ids = [f"{prefix}~r{n}" for n in range(start, end+1)]
    print(f"Mapping {prefix} r{start}-{end} → {new_eid}: {len(target_ids)} ids")

    query = {"ehr_id": {"$in": target_ids}, "cn": {"$all": cn_filters}}
    projection = {"_id": 1, "ehr_id": 1}
    cursor = coll.find(query, projection)
    if args.limit:
        cursor = cursor.limit(args.limit)

    updates = []
    for doc in cursor:
        updates.append(({'_id': doc['_id'], 'ehr_id': doc['ehr_id']}, {'$set': {'ehr_id': new_eid}}))

    print(f"  Found {len(target_ids)} potential ids; preparing {len(updates)} updates.")
    if not updates:
        continue

    audit_file = f"{prefix}_r{start}-{end}_to_{new_eid}_ids.txt"
    with open(audit_file, 'w') as f:
        for filt, _ in updates:
            f.write(str(filt['_id']) + '\n')
    print(f"  Wrote IDs to {audit_file}")

    matched_total = 0
    modified_total = 0
    for filt, upd in updates:
        res = safe_update(filt, upd)
        if res:
            matched_total += res.matched_count
            modified_total += res.modified_count

    print(f"  Completed updates: matched {matched_total}, modified {modified_total}\n")
