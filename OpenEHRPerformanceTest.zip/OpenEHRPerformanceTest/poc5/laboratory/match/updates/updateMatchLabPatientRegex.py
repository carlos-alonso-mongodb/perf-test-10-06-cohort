#!/usr/bin/env python3
"""
bulk_update_ehr_ids.py – add `p` = last(pc) to every `cn` element
for specified ehr_id values, with retry/backoff on lock timeouts.

Usage example:
    python bulk_update_ehr_ids.py \
      --db CatSalutCDR --coll compositions \
      --new-eid X1 --new-eid X10 --new-eid X50 \
      [--limit 100] [--retries 5] [--backoff 0.2]
"""
import os
import argparse
import time
from datetime import datetime, timezone
from pymongo import MongoClient
from pymongo.errors import WriteError
from bson.int64 import Int64

# ─── CLI ────────────────────────────────────────────────────────
parser = argparse.ArgumentParser(
    description="Add `p` field (last element of pc) to each cn node"
)
parser.add_argument("--db",       required=True, help="database name")
parser.add_argument("--coll",     required=True, help="collection name")
parser.add_argument(
    "--new-eid",
    required=True,
    action="append",
    help="ehr_id value to target; may repeat for multiple IDs"
)
parser.add_argument(
    "--limit",
    type=int,
    default=None,
    help="optional per-eid document limit"
)
parser.add_argument(
    "--retries",
    type=int,
    default=5,
    help="max retry attempts per update on lock timeout"
)
parser.add_argument(
    "--backoff",
    type=float,
    default=0.2,
    help="base backoff seconds (exponential)"
)
args = parser.parse_args()

# ─── MongoDB setup ─────────────────────────────────────────────
client = MongoClient(
    host=os.environ.get("MONGODB_URI"),
    appname="ehr_id-bulk-updater"
)
coll = client[args.db][args.coll]

# ─── static cn filters ─────────────────────────────────────────
cn_filters = [
    {"$elemMatch": {
        "pch": Int64(3360793852075631416),
        "d.v.df.cs": "00100"
    }},
    {"$elemMatch": {
        "pch": Int64(5725676661766718380),
        "d.origin.v": {"$gte": datetime(2000, 11, 9, tzinfo=timezone.utc)}
    }},
    {"$elemMatch": {
        "pch": Int64(-5797776851620394899),
        "d.v.df.cs": "789-8",
        "d.v.df.tid.v": "2.16.840.1.113883.6.1"
    }},
]

# ─── helper: safe update with retries ──────────────────────────
def safe_update(filter_doc, update_doc):
    attempts = 0
    while attempts <= args.retries:
        try:
            return coll.update_one(filter_doc, update_doc)
        except WriteError as e:
            code = getattr(e, "code", None)
            # shard-move lock timeout codes
            if code in (24, 72) and attempts < args.retries:
                wait = args.backoff * (2 ** attempts)
                print(f"    Lock timeout, retry {attempts+1} in {wait:.2f}s…")
                time.sleep(wait)
                attempts += 1
                continue
            print("    Update failed:", e)
            return None
    print("    Max retries reached, skipping.")
    return None

# ─── main loop ─────────────────────────────────────────────────
for new_eid in args.new_eid:
    print(f"Processing ehr_id = {new_eid!r}")
    # find matching docs
    query = {"ehr_id": new_eid, "cn": {"$all": cn_filters}}
    cursor = coll.find(query, {"_id": 1})
    if args.limit:
        cursor = cursor.limit(args.limit)

    docs = list(cursor)
    print(f"  Found {len(docs)} documents")

    if not docs:
        continue

    # audit file
    audit_file = f"audit_{new_eid}.txt"
    with open(audit_file, "w") as f:
        for doc in docs:
            f.write(str(doc["_id"]) + "\n")
    print(f"  Wrote audit file: {audit_file}")

    # apply pipeline update to set p = last(pc) in each cn node
    matched_total = 0
    modified_total = 0
    for doc in docs:
        filt = {"_id": doc["_id"]}
        pipeline = [
            {
                "$set": {
                    "cn": {
                        "$map": {
                            "input": "$cn",
                            "as":    "node",
                            "in": {
                                "$mergeObjects": [
                                    "$$node",
                                    {
                                        # compute p = node.pc[-1]
                                        "p": {
                                            "$arrayElemAt": [
                                                "$$node.pc",
                                                { "$subtract": [ { "$size": "$$node.pc" }, 1 ] }
                                            ]
                                        }
                                    }
                                ]
                            }
                        }
                    }
                }
            }
        ]
        res = safe_update(filt, pipeline)
        if res:
            matched_total  += res.matched_count
            modified_total += res.modified_count

    print(f"  Completed: matched {matched_total}, modified {modified_total}\n")