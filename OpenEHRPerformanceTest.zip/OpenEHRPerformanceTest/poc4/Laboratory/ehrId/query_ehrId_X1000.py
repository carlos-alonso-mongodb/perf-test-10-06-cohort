# Laboratory/query_ehrId_X1.py

from datetime import datetime
from helper import execute_aggregation

# target namespace
ns = "CatSalutCDR.finalCompositions"

# this filter will match exactly the batch-1 clones (suffix “X1”)
pipeline = [
    {
        "$match": {
    "ehr_id": "7321ad5a-94c5-44db-e5b3-b76e73f05d63~r148XL",
    "cn": {
        "$all": [
            {
                "$elemMatch": {
                    "d.ani": 240000,
                    "a": {"$all": [18, 10000, 20000, 30000, 19]},
                    "d.v.df.cs": {
                        "$in": [
                            "718-7", "62461000122102", "33695-8", "16676-9",
                            "10851-4", "LL1937-3", "88186-2", "77955-3",
                            "41216-3", "7894-9", "16925-0", "38392-7",
                            "31870-9", "74408-6", "17327-8", "98080-5",
                            "82301-3", "31946-7", "31947-5", "21834-2",
                            "21835-9", "31966-5", "21503-8", "60270-6",
                            "33689-1", "82731-1"
                        ]
                    }
                }
            },
            {
                "$elemMatch": {
                    "d.cx.st.v": {
                        "$gte": datetime.fromisoformat("2024-06-19T07:54:16.345")
                    }
                }
            },
            {
                "$elemMatch": {
                    "d.ani": 110000,
                    "a": {"$all": [10000, 3, 50000]},
                    "d.v.df.cs": "H43001903X1000"
                }
            }
        ]
    }
}    },
    {   
        "$limit": 100
    }
]


def run_query():
    return execute_aggregation(ns, pipeline)

if __name__ == "__main__":
    run_query()